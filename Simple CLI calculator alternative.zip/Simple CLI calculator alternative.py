while True: 

    x= input("What do you want to calculate? : ")
    print(eval(x))
