from unittest import result


a = int(input("Enter value for a: "))
b = int(input("Enter value for b: "))
c = a + b
print(a," + ",b, " = ",c)